<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpressmidterm' );

/** MySQL database username */
define( 'DB_USER', 'thuong.hoang2012' );

/** MySQL database password */
define( 'DB_PASSWORD', 'nhom2012' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '9q[}G=J{0@W-/ |z;Kcz`n!J#:P r*r%f`C!ZO9WKf[7rxt_>fD1L`St[w5Z[+Oz' );
define( 'SECURE_AUTH_KEY',  'j/8+}lF]aP1n+J6dm,AZ! <niO.x-N~$LR~K<Uufvo(I)X/~g2WZ?l)#M!_4!VK_' );
define( 'LOGGED_IN_KEY',    'te~NH968$|.f$(/sKCj]!@^NFqdR|.gSyk|Ws{Fn*cx:|:vqyO7Q&^M[FIHgB/pb' );
define( 'NONCE_KEY',        '~iHio(B%oX8sv0B}rgHNtg]#N,O*SkavsDr7;=nmlo0}!yhyJ*Ify}Xp;kOq5p#F' );
define( 'AUTH_SALT',        'ygctyUVV&{Th:gewPnJL -5&<+`h/&Z<%uRc .J5?t5-Bort:Nfm,sYln:n([ZxG' );
define( 'SECURE_AUTH_SALT', 'a%LR[(,;upSu>cRkVL3.RN/w.2Hp=zo%{QAoYqu)D%btp*lk`!Of+as{0M5)/3#+' );
define( 'LOGGED_IN_SALT',   'uqnJ7(S1EVzDQN6v ,BSTXb4k>! yGl7#0WT kt]l<]ZHzc5Lk/4IE}1+=i`j+0R' );
define( 'NONCE_SALT',       'XHaiOszAj!lU]Bb{O*BmNUpH[/2@8gXB20]2/M^Qb)Yd9EERgEAyXNaA:EwNAZ<!' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
